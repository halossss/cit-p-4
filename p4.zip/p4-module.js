const { data } = require('./p4-data.js');

function getQuestions() {
    return data.map((question) => question.question);
}

function getAnswers() {
    return data.map((answer) => answer.answer);
}

function getQuestionsAnswers() {
    return data.map((item) => {
        return {
            question: item.question,
            answer: item.answer
        };
    });
}

function getQuestion(number = "") {
    const index = parseInt(number);
    if (!isNaN(index) && index >= 1 && index <= data.length) {
        const question = data[index - 1]; 
        return {
            question: question.question,
            number: index,
            error: ""
        };
    } else {
        return {
            question: "",
            number: "err",
            error: "Invalid question number"
        };
    }
}


function getAnswer(number = "") {
    const index = parseInt(number);
    if (!isNaN(index) && index >= 1 && index <= data.length) {
        const answer = data[index - 1]; 
        return {
            answer: answer.answer,
            number: index,
            error: ""
        };
    } else {
        return {
            answer: "",
            number: "err",
            error: "Invalid answer number"
        };
    }
}


function getQuestionAnswer(number = "") {
    const index = parseInt(number);
    if (!isNaN(index) && index >= 1 && index <= data.length) {
        const item = data[index - 1];
        if (item) {
            return {
                question: item.question,
                answer: item.answer,
                number: index,
                error: ""
            };
        } else {
            return {
                question: "",
                answer: "",
                number: "err",
                error: "Question and Answer not found"
            };
        }
    } else {
        return {
            question: "",
            answer: "",
            number: "err",
            error: "Invalid question/answer number"
        };
    }
}





/*****************************
  Module function testing
******************************/
// function testing(category, ...args) {
//     console.log(`\n** Testing ${category} **`);
//     console.log("-------------------------------");
//     for (const o of args) {
//       console.log(`-> ${category}${o.d}:`);
//       console.log(o.f);
//     }
//   }
  
//   // Set a constant to true to test the appropriate function
//   const testGetQs = false;
//   const testGetAs = false;
//   const testGetQsAs = false;
//   const testGetQ = false;     // Extra credit later
//   const testGetA = false;     // Extra credit later
//   const testGetQA = true;
//   const testAdd = false;      // Extra credit
//   const testUpdate = false;   // Extra credit
//   const testDelete = false;   // Extra credit
  
// // getQuestions()
// if (testGetQs) {
//     testing("getQuestions", { d: "()", f: getQuestions() });
//   }
  
//   // getAnswers()
//   if (testGetAs) {
//     testing("getAnswers", { d: "()", f: getAnswers() });
//   }
  
//   // getQuestionsAnswers()
//   if (testGetQsAs) {
//     testing("getQuestionsAnswers", { d: "()", f: getQuestionsAnswers() });
//   }
  
//   // getQuestion()
//   if (testGetQ) {
//     testing(
//       "getQuestion",
//       { d: "()", f: getQuestion() },      // Extra credit: +1
//       { d: "(0)", f: getQuestion(0) },    // Extra credit: +1
//       { d: "(1)", f: getQuestion(1) },
//       { d: "(4)", f: getQuestion(4) }     // Extra credit: +1
//     );
//   }
  
//   // getAnswer()
//   if (testGetA) {
//     testing(
//       "getAnswer",
//       { d: "()", f: getAnswer() },        // Extra credit: +1
//       { d: "(0)", f: getAnswer(0) },      // Extra credit: +1
//       { d: "(1)", f: getAnswer(1) },
//       { d: "(4)", f: getAnswer(4) }       // Extra credit: +1
//     );
//   }
  
//   // getQuestionAnswer()
//   if (testGetQA) {
//     testing(
//       "getQuestionAnswer",
//       { d: "()", f: getQuestionAnswer() },    // Extra credit: +1
//       { d: "(0)", f: getQuestionAnswer(0) },  // Extra credit: +1
//       { d: "(1)", f: getQuestionAnswer(1) },
//       { d: "(4)", f: getQuestionAnswer(4) }   // Extra credit: +1
//     );
//   }

module.exports = {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer 
};
