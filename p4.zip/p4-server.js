const fastify = require('fastify')();
const { getQuestions, getAnswers, getQuestionsAnswers, getQuestion, getAnswer, getQuestionAnswer } = require('./p4-module.js');

fastify.get('/cit/question', (request, reply) => {
    reply.send({
        error: "",
        statusCode: 200,
        questions: getQuestions()
    });
});

fastify.get('/cit/answer', (request, reply) => {
    reply.send({
        error: "",
        statusCode: 200,
        answers: getAnswers()
    });
});

fastify.get('/cit/questionanswer', (request, reply) => {
    reply.send({
        error: "",
        statusCode: 200,
        questions_answers: getQuestionsAnswers()
    });
});

fastify.get('/cit/question/:number', (request, reply) => {
    const { number } = request.params;
    const { question } = getQuestion(number);
    reply.send({
        error: "",
        statusCode: 200,
        question: question,
        number: parseInt(number)
    });
});

fastify.get('/cit/answer/:number', (request, reply) => {
    const { number } = request.params;
    const { answer } = getAnswer(number);
    reply.send({
        error: "",
        statusCode: 200,
        answer: answer,
        number: parseInt(number)
    });
});

fastify.get('/cit/questionanswer/:number', (request, reply) => {
    const { number } = request.params;
    const { question, answer } = getQuestionAnswer(number);
    reply.send({
        error: "",
        statusCode: 200,
        question: question,
        answer: answer,
        number: parseInt(number)
    });
});

fastify.get('*', (request, reply) => {
    reply.code(404).send({
        error: "Route not found",
        statusCode: 404
    });
});

fastify.listen(8080, 'localhost', (err, address) => {
    if (err) {
        console.error(err);
        process.exit(1);
    }
    console.log(`Server listening on ${address}`);
});


